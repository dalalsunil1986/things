## Jumbo jQuery Installation

Step 1
------
Install latest version of NodeJS from http://nodejs.org/

Step 2
------
Run the command in console "npm install"

Step 3
------
Happy Coding!